//itt adom meg, hogy milyen tulajdonságai vannak egy mezőnek
typedef struct {
     int x; //sor
     int y; //oszlop
     char babu; //király = k, királynő = q, futó = b, ló = h, bástya = r, paraszt = p
     char szin; //fehér = w, fekete = b
} Mezo;