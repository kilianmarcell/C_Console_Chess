#include "debugmalloc.h"
#include "mezo.h"
#include "babu_lepesek.h"

int sakk_ellenoriz(Mezo** tabla);
int oda_tud_e_lepni_seged(Mezo** tabla, Mezo* m, char szin);
Mezo* feher_kiraly_mezo(Mezo** tabla);
Mezo* fekete_kiraly_mezo(Mezo** tabla);

//ellenõrzi, hogy sakk van-e
int sakk_ellenoriz(Mezo** tabla) {
     Mezo* feher = feher_kiraly_mezo(tabla);
     Mezo* fekete = fekete_kiraly_mezo(tabla);

     //átlós lépések
     if (feher->x - 1 >= 0 && feher->y + 1 <= 7) {
          if (jobbra_fel_ellenoriz(tabla, &tabla[feher->x - 1][feher->y + 1], 'w')) return 1;
     }
     if (fekete->x - 1 >= 0 && fekete->y + 1 <= 7) {
          if (jobbra_fel_ellenoriz(tabla, &tabla[fekete->x - 1][fekete->y + 1], 'b')) return 2;
     }

     if (feher->x + 1 <= 7 && feher->y + 1 <= 7) {
          if (jobbra_le_ellenoriz(tabla, &tabla[feher->x + 1][feher->y + 1], 'w')) return 1;
     }
     if (fekete->x + 1 <= 7 && fekete->y + 1 <= 7) {
          if (jobbra_le_ellenoriz(tabla, &tabla[fekete->x + 1][fekete->y + 1], 'b')) return 2;
     }

     if (feher->x - 1 >= 0 && feher->y - 1 >= 0) {
          if (balra_fel_ellenoriz(tabla, &tabla[feher->x - 1][feher->y - 1], 'w')) return 1;
     }
     if (fekete->x - 1 >= 0 && fekete->y - 1 >= 0) {
          if (balra_fel_ellenoriz(tabla, &tabla[fekete->x - 1][fekete->y - 1], 'b')) return 2;
     }

     if (feher->x + 1 <= 7 && feher->y - 1 >= 0) {
           if (balra_le_ellenoriz(tabla, &tabla[feher->x + 1][feher->y - 1], 'w')) return 1;
     }
     if (fekete->x + 1 <= 7 && fekete->y - 1 >= 0) {
          if (balra_le_ellenoriz(tabla, &tabla[fekete->x + 1][fekete->y - 1], 'b')) return 2;
     }

     //egyenes lépések
     if (feher->x - 1 >= 0) {
          if (egyenesen_fel_ellenoriz(tabla, &tabla[feher->x - 1][feher->y], 'w')) return 1;
     }
     if (fekete->x - 1 >= 0) {
          if (egyenesen_fel_ellenoriz(tabla, &tabla[fekete->x - 1][fekete->y], 'b')) return 2;
     }

     if (feher->x + 1 <= 7) {
          if (egyenesen_le_ellenoriz(tabla, &tabla[feher->x + 1][feher->y], 'w')) return 1;
     }
     if (fekete->x + 1 <= 7) {
          if (egyenesen_le_ellenoriz(tabla, &tabla[fekete->x + 1][fekete->y], 'b')) return 2;
     }

     if (feher->y + 1 <= 7) {
          if (egyenesen_jobbra_ellenoriz(tabla, &tabla[feher->x][feher->y + 1], 'w')) return 1;
     }
     if (fekete->y + 1 <= 7) {
          if (egyenesen_jobbra_ellenoriz(tabla, &tabla[fekete->x][fekete->y + 1], 'b')) return 2;
     }

     if (feher->y - 1 >= 0) {
          if (egyenesen_balra_ellenoriz(tabla, &tabla[feher->x][feher->y - 1], 'w')) return 1;
     }
     if (fekete->y - 1 >= 0) {
          if (egyenesen_balra_ellenoriz(tabla, &tabla[fekete->x][fekete->y - 1], 'b')) return 2;
     }

     //ló lépések
     if (lo_van_e(tabla, feher) == 1) return 1;
     if (lo_van_e(tabla, fekete) == 1) return 2;

     //paraszt lépések
     if (paraszt_van_e(tabla, feher) == 1) return 1;
     if (paraszt_van_e(tabla, fekete) == 1) return 2;

     return 0;
}

//ellenõrzi, hogy a bemenetként érkezõ bábu ha király lenne, sakk lenne e
int oda_tud_e_lepni_seged(Mezo** tabla, Mezo* m, char szin) {
     if (jobbra_fel_ellenoriz(tabla, &tabla[m->x - 1][m->y + 1], szin)) return 1;
     if (jobbra_le_ellenoriz(tabla, &tabla[m->x + 1][m->y + 1], szin)) return 1;
     if (balra_fel_ellenoriz(tabla, &tabla[m->x - 1][m->y - 1], szin)) return 1;
     if (balra_le_ellenoriz(tabla, &tabla[m->x + 1][m->y - 1], szin)) return 1;

     if (egyenesen_fel_ellenoriz(tabla, &tabla[m->x - 1][m->y], szin)) return 1;
     if (egyenesen_le_ellenoriz(tabla, &tabla[m->x + 1][m->y], szin)) return 1;
     if (egyenesen_jobbra_ellenoriz(tabla, &tabla[m->x][m->y + 1], szin)) return 1;
     if (egyenesen_balra_ellenoriz(tabla, &tabla[m->x][m->y - 1], szin)) return 1;

     if (lo_van_e(tabla, m) == 1) return 1;

     if (paraszt_van_e(tabla, m) == 1) return 1;

     return 0;
}

//a fehér király mezőjét adja meg
Mezo* feher_kiraly_mezo(Mezo** tabla) {
     for (int i = 0; i < 8; ++i) {
          for (int j = 0; j < 8; ++j) {
               if (tabla[i][j].babu == 'k' && tabla[i][j].szin == 'w') return &tabla[i][j];
          }
     }
     return &tabla[0][0];
}

//a fekete király mezőjét adja meg
Mezo* fekete_kiraly_mezo(Mezo** tabla) {
     for (int i = 0; i < 8; ++i) {
          for (int j = 0; j < 8; ++j) {
               if (tabla[i][j].babu == 'k' && tabla[i][j].szin == 'b') return &tabla[i][j];
          }
     }
     return &tabla[0][0];
}
