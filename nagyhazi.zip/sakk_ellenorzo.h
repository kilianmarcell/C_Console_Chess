#ifndef SAKK_ELLENORZO_H_INCLUDED
#define SAKK_ELLENORZO_H_INCLUDED

int sakk_ellenoriz(Mezo** tabla);
int oda_tud_e_lepni_seged(Mezo** tabla, Mezo* m, char szin);
Mezo* feher_kiraly_mezo(Mezo** tabla);
Mezo* fekete_kiraly_mezo(Mezo** tabla);

#endif // SAKK_ELLENORZO_H_INCLUDED
