#ifndef MENTES_BEOLVAS_H_INCLUDED
#define MENTES_BEOLVAS_H_INCLUDED

#include "lepes.h"

void fajlbair(FILE* mentes, Lepes* lepes);
void jatek_mentese(Lepes* lepes);
void jatek_betolt();

#endif // MENTES_BEOLVAS_H_INCLUDED
