#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "debugmalloc.h"
#include "mezo.h"
#include "lepes.h"
#include "konvertalasok.h"
#include "babu_lepesek.h"
#include "sakk_ellenorzo.h"
#include "lepes_ellenorzo.h"
#include "menu.h"

int main(void) {
     SetConsoleOutputCP(650001);
     menu();
}
