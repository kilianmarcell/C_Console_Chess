#include <stdlib.h>

//ez a met�dus kil�p a programb�l
void kilepes() {
     exit(0);
}
