#include <stdio.h>

//hiba�zenetet �r a felhaszn�l�nak, visszajelz�st ad, ha helytelen bemeneti �rt�ket adott meg a felhaszn�l�
void hibauzenet(char *uzenet) {
     printf("Kerem ervenyes %s adjon meg!\n\n", uzenet);
}
