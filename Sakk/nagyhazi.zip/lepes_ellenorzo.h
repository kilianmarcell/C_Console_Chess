#ifndef LEPES_ELLENORZO_H_INCLUDED
#define LEPES_ELLENORZO_H_INCLUDED

int lepes_ellenorzes(Mezo* honnan, Mezo* hova, char szin);
void paraszt_cserelese(Mezo* m);
int kiraly_tud_e_lepni(Mezo* m);
int pozicio_cserel(Mezo* honnan, Mezo* hova, char szin);

#endif // LEPES_ELLENORZO_H_INCLUDED
