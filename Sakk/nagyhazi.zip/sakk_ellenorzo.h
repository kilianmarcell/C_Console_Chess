#ifndef SAKK_ELLENORZO_H_INCLUDED
#define SAKK_ELLENORZO_H_INCLUDED

int sakk_ellenoriz(Mezo* feher, Mezo* fekete);
int oda_tud_e_lepni_seged(Mezo* m, char szin);

#endif // SAKK_ELLENORZO_H_INCLUDED
