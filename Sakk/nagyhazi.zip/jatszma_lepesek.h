#ifndef JATSZMA_LEPESEK_H_INCLUDED
#define JATSZMA_LEPESEK_H_INCLUDED

void elozo_lepesek_kiir(Lepes* l, int szamol);
void aktualis_megjelenit(Mezo* m);
int volt_e_paraszt_csere();
void visszalepes();

#endif // JATSZMA_LEPESEK_H_INCLUDED
