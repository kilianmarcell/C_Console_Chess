#ifndef HIBAUZENET_H_INCLUDED
#define HIBAUZENET_H_INCLUDED

void hibauzenet(char *uzenet);

#endif // HIBAUZENET_H_INCLUDED
