#ifndef KILEPES_H_INCLUDED
#define KILEPES_H_INCLUDED

void kilepes();

#endif // KILEPES_H_INCLUDED
