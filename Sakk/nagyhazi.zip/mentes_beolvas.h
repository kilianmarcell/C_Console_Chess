#ifndef MENTES_BEOLVAS_H_INCLUDED
#define MENTES_BEOLVAS_H_INCLUDED

void jatek_mentese();
void fajlbair(FILE* mentes, Lepes* lepes);
void jatek_betolt(int* navigal);

#endif // MENTES_BEOLVAS_H_INCLUDED
