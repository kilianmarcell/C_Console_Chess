#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menu(int* navigal);

#endif // MENU_H_INCLUDED
