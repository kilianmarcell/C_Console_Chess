#ifndef JATSZMA_H_INCLUDED
#define JATSZMA_H_INCLUDED
#include "mezo.h"
#include "lepes.h"

void uj_jatek();
int lepesek_megszamolasa(Lepes* l, int ossz);
int egy_lepes(Mezo** tabla, Lepes* lepes, char* betolt_e, int betolt_vege);
Mezo** tabla_betolt();

#endif // JATSZMA_H_INCLUDED
