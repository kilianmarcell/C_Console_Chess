#ifndef LEPES_ELLENORZO_H_INCLUDED
#define LEPES_ELLENORZO_H_INCLUDED

int lepes_ellenorzes(Mezo** tabla, Lepes* lepes, Mezo* honnan, Mezo* hova, char szin);
void paraszt_cserelese(Mezo* m);
int kiraly_tud_e_lepni(Mezo** tabla, Mezo* m);
int pozicio_cserel(Mezo** tabla, Lepes* lepes, Mezo* honnan, Mezo* hova, char szin);

#endif // LEPES_ELLENORZO_H_INCLUDED
