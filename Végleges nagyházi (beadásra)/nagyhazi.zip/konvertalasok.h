#ifndef KONVERTALASOK_H_INCLUDED
#define KONVERTALASOK_H_INCLUDED

int helyesxy(int* x, int* y);
int helyes_sor_oszlop(char* honnanoszlop, char* hovaoszlop);
int betubol_szamra_konvertal(char* betu);
char *baburakonvertal(char betu, char szin);
int tablan_belul_van_e(int x, int y);
int karakterbol_szamra_konvertal(char c);

#endif // KONVERTALASOK_H_INCLUDED
