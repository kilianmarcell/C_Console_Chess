#ifndef MEZO_H_INCLUDED
#define MEZO_H_INCLUDED

typedef struct {
     int x;
     int y;
     char babu;
     char szin;
} Mezo;

#endif
