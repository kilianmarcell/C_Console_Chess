#include <stdio.h>
#include <stdlib.h>
#include "debugmalloc.h"
#include "jatszma.h"
#include "mentes_beolvas.h"
#include "hasznalati_utmutato.h"
#include "kilepes.h"
#include "hibauzenet.h"

//amikor betölt a program ez a metódus fut le először, ez a metódus a menüt jelenti, itt dönti el a felhasználó,
//hogy mit szeretne a programon belül csinálni, ez a metódus a felhasználó által választott metódust hívja meg
void menu() {
     system("cls");
     int beolvas;
     printf("- Sakk -\n\n1. Uj jatek\n2. Jatek betoltese\n3. Hasznalati utmutato\n\n9. Kilepes\n\n");
     printf("Valasztas: ");
     scanf("%d", &beolvas);
     switch (beolvas) {
          case 1:
               system("cls");
               uj_jatek();
               break;
          case 2:
               system("cls");
               jatek_betolt();
               break;
          case 3:
               system("cls");
               hasznalati_utmutato();
               break;
          case 9:
               kilepes();
               break;
          default:
               system("cls");
               hibauzenet("erteket");
               menu();
               break;
     }
}
